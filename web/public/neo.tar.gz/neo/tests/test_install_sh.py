"""Tests for install.sh."""

from __future__ import annotations

import os
import subprocess
import tarfile
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[2]
INSTALL_SH = REPO_ROOT / "install.sh"


def _run_install(env: dict[str, str], *, cwd: Path | None = None) -> subprocess.CompletedProcess[str]:
    merged = {**os.environ, **env}
    return subprocess.run(
        ["bash", str(INSTALL_SH)],
        cwd=cwd or REPO_ROOT,
        env=merged,
        capture_output=True,
        text=True,
        check=False,
    )


def test_install_sh_syntax():
    result = subprocess.run(
        ["bash", "-n", str(INSTALL_SH)],
        capture_output=True,
        text=True,
        check=False,
    )
    assert result.returncode == 0, result.stderr


@pytest.mark.skip(reason="Slow: runs real install.sh, eliminated per optimization request")
def test_install_from_source_dir(tmp_path: Path):
    result = _run_install(
        {
            "NEO_SOURCE_DIR": str(REPO_ROOT),
            "NEO_INSTALL_DIR": str(tmp_path / "ignored"),
            "NEO_NO_PATH": "1",
            "HOME": str(tmp_path),
        },
    )
    assert result.returncode == 0, result.stderr + result.stdout
    venv_python = REPO_ROOT / ".venv" / "bin" / "python"
    assert venv_python.is_file()
    assert "Neo is installed." in result.stdout
    assert "neo    # first run" in result.stdout


@pytest.mark.skip(reason="Slow: runs real install.sh, eliminated per optimization request")
def test_install_idempotent_with_existing_venv(tmp_path: Path):
    env = {
        "NEO_SOURCE_DIR": str(REPO_ROOT),
        "NEO_NO_PATH": "1",
        "HOME": str(tmp_path),
    }
    first = _run_install(env)
    assert first.returncode == 0, first.stderr + first.stdout
    second = _run_install(env)
    assert second.returncode == 0, second.stderr + second.stdout
    assert "Using existing venv" in second.stdout
