"""Tests for agent loop orchestration."""

import json
from pathlib import Path

from agent.loop import AgentLoop, LoopOutcome
from agent.types import (
    AgentAction,
    AgentStep,
    PlanItem,
    PlanItemStatus,
    ToolResult,
)
from agent.ui import ConversationUI

_ALLOWED = ["gpt-4.1-nano", "gpt-5.4-nano", "gpt-5.4-mini", "gpt-5.5"]


def _llm_responses(responses: list[AgentStep]):
    payloads = [json.dumps(step.model_dump(mode="json")) for step in responses]
    index = {"i": 0}

    def fake_llm(**_kwargs):
        i = index["i"]
        index["i"] += 1
        return payloads[i]

    return fake_llm


def test_loop_default_reasoning_effort_applied(tmp_path: Path, monkeypatch):
    env_file = tmp_path / ".env"
    env_file.write_text("GOODBOY_REASONING_EFFORT=low\n", encoding="utf-8")
    monkeypatch.setattr("settings.ENV_FILE", env_file)
    from settings import get_settings

    get_settings.cache_clear()

    captured: dict[str, object] = {}

    def fake_llm(**kwargs):
        captured.update(kwargs)
        return json.dumps(
            AgentStep(
                action=AgentAction.TASK_COMPLETE,
                message="ok",
            ).model_dump(mode="json")
        )

    loop = AgentLoop(
        workspace=tmp_path,
        max_turns=5,
        allowed_models=_ALLOWED,
        model="gpt-5.4-nano",
        llm_call=fake_llm,
    )
    loop.run("task")
    assert captured.get("reasoning_effort") == "low"
    get_settings.cache_clear()


def test_loop_task_complete(tmp_path: Path):
    loop = AgentLoop(
        workspace=tmp_path,
        max_turns=5,
        allowed_models=_ALLOWED,
        llm_call=_llm_responses(
            [
                AgentStep(
                    action=AgentAction.TASK_COMPLETE,
                    message="All done.",
                )
            ]
        ),
    )
    result = loop.run("do something")
    assert result.outcome == LoopOutcome.TASK_COMPLETE
    assert result.message == "All done."
    assert len(result.context.turns) == 1


def test_loop_plan_printed_on_create_and_each_completion(tmp_path: Path, capsys):
    ui = ConversationUI()
    loop = AgentLoop(
        workspace=tmp_path,
        max_turns=8,
        allowed_models=_ALLOWED,
        ui=ui,
        llm_call=_llm_responses(
            [
                AgentStep(
                    action=AgentAction.UPDATE_PLAN,
                    plan_items=[
                        PlanItem(
                            id="1",
                            text="recon",
                            status=PlanItemStatus.IN_PROGRESS,
                        ),
                        PlanItem(
                            id="2",
                            text="edit file",
                            status=PlanItemStatus.PENDING,
                        ),
                    ],
                ),
                AgentStep(
                    action=AgentAction.UPDATE_PLAN,
                    plan_items=[
                        PlanItem(
                            id="1",
                            text="recon",
                            status=PlanItemStatus.DONE,
                        ),
                        PlanItem(
                            id="2",
                            text="edit file",
                            status=PlanItemStatus.IN_PROGRESS,
                        ),
                    ],
                ),
                AgentStep(
                    action=AgentAction.UPDATE_PLAN,
                    plan_items=[
                        PlanItem(
                            id="1",
                            text="recon",
                            status=PlanItemStatus.DONE,
                        ),
                        PlanItem(
                            id="2",
                            text="edit file",
                            status=PlanItemStatus.DONE,
                        ),
                    ],
                ),
                AgentStep(
                    action=AgentAction.TASK_COMPLETE,
                    message="done",
                ),
            ]
        ),
    )
    result = loop.run("refactor with plan")
    assert result.outcome == LoopOutcome.TASK_COMPLETE
    out = capsys.readouterr().out
    assert out.count("(plan)") == 3
    assert "1. recon" in out
    assert "2. edit file" in out
    assert '1/2 step "recon"' in out
    assert '2/2 step "edit file"' in out


def test_loop_plan_printed_when_bundled_with_shell(tmp_path: Path, capsys):
    ui = ConversationUI()
    bundled = json.dumps(
        AgentStep(
            action=AgentAction.RUN_SHELL,
            command="echo hi",
        ).model_dump(mode="json")
    ) + json.dumps(
        AgentStep(
            action=AgentAction.UPDATE_PLAN,
            plan_items=[
                PlanItem(
                    id="1",
                    text="recon",
                    status=PlanItemStatus.IN_PROGRESS,
                ),
                PlanItem(
                    id="2",
                    text="edit file",
                    status=PlanItemStatus.PENDING,
                ),
            ],
        ).model_dump(mode="json")
    )
    payloads = [
        bundled,
        json.dumps(
            AgentStep(
                action=AgentAction.TASK_COMPLETE,
                message="done",
            ).model_dump(mode="json")
        ),
    ]
    index = {"i": 0}

    def fake_llm(**_kwargs):
        raw = payloads[index["i"]]
        index["i"] += 1
        return raw

    loop = AgentLoop(
        workspace=tmp_path,
        max_turns=5,
        allowed_models=_ALLOWED,
        ui=ui,
        llm_call=fake_llm,
    )
    result = loop.run("explore")
    assert result.outcome == LoopOutcome.TASK_COMPLETE
    out = capsys.readouterr().out
    assert out.count("(plan)") == 1
    assert "1. recon" in out
    assert "2. edit file" in out
    assert '1/2 step "recon"' in out


def test_loop_plan_not_printed_on_in_progress_only(tmp_path: Path, capsys):
    ui = ConversationUI()
    loop = AgentLoop(
        workspace=tmp_path,
        max_turns=5,
        allowed_models=_ALLOWED,
        ui=ui,
        llm_call=_llm_responses(
            [
                AgentStep(
                    action=AgentAction.UPDATE_PLAN,
                    plan_items=[
                        PlanItem(
                            id="1",
                            text="recon",
                            status=PlanItemStatus.IN_PROGRESS,
                        ),
                        PlanItem(
                            id="2",
                            text="edit file",
                            status=PlanItemStatus.PENDING,
                        ),
                    ],
                ),
                AgentStep(
                    action=AgentAction.UPDATE_PLAN,
                    plan_items=[
                        PlanItem(
                            id="1",
                            text="recon",
                            status=PlanItemStatus.PENDING,
                        ),
                        PlanItem(
                            id="2",
                            text="edit file",
                            status=PlanItemStatus.IN_PROGRESS,
                        ),
                    ],
                ),
                AgentStep(
                    action=AgentAction.TASK_COMPLETE,
                    message="done",
                ),
            ]
        ),
    )
    result = loop.run("refactor with plan")
    assert result.outcome == LoopOutcome.TASK_COMPLETE
    out = capsys.readouterr().out
    assert out.count("(plan)") == 1


def test_loop_runs_shell_then_completes(tmp_path: Path):
    loop = AgentLoop(
        workspace=tmp_path,
        max_turns=5,
        allowed_models=_ALLOWED,
        llm_call=_llm_responses(
            [
                AgentStep(
                    action=AgentAction.RUN_SHELL,
                    command="echo loop-test",
                ),
                AgentStep(
                    action=AgentAction.TASK_COMPLETE,
                    message="finished",
                ),
            ]
        ),
    )
    result = loop.run("echo test")
    assert result.outcome == LoopOutcome.TASK_COMPLETE
    assert len(result.context.turns) == 2
    assert result.context.turns[0].tool_result is not None
    assert "loop-test" in result.context.turns[0].tool_result.stdout


def test_loop_need_user_input(tmp_path: Path):
    loop = AgentLoop(
        workspace=tmp_path,
        allowed_models=_ALLOWED,
        llm_call=_llm_responses(
            [
                AgentStep(
                    action=AgentAction.NEED_USER_INPUT,
                    message="Which file?",
                )
            ]
        ),
    )
    result = loop.run("edit file")
    assert result.outcome == LoopOutcome.NEED_USER_INPUT
    assert result.message == "Which file?"


def test_loop_invalid_json_twice_fails(tmp_path: Path):
    calls = {"n": 0}

    def bad_llm(**_kwargs):
        calls["n"] += 1
        return "not json"

    loop = AgentLoop(
        workspace=tmp_path,
        max_turns=5,
        allowed_models=_ALLOWED,
        llm_call=bad_llm,
    )
    result = loop.run("task")
    assert result.outcome == LoopOutcome.FAILED
    assert "invalid JSON" in result.message


def test_loop_str_replace_empty_new_string_continues(tmp_path: Path):
    """Deletion edits with new_string: \"\" must parse, not abort with invalid JSON."""
    calls = {"n": 0}

    def llm(**_kwargs):
        calls["n"] += 1
        if calls["n"] == 1:
            return json.dumps(
                {
                    "action": "str_replace",
                    "path": "noop.txt",
                    "old_string": "never matches",
                    "new_string": "",
                }
            )
        return json.dumps(
            AgentStep(
                action=AgentAction.TASK_COMPLETE,
                message="done",
            ).model_dump(mode="json")
        )

    loop = AgentLoop(
        workspace=tmp_path,
        max_turns=5,
        allowed_models=_ALLOWED,
        llm_call=llm,
    )
    result = loop.run("remove a block from release.sh")
    assert result.outcome != LoopOutcome.FAILED or "invalid JSON" not in (
        result.message or ""
    )
    assert not any(
        "str_replace requires 'new_string'" in err
        for err in result.context.parse_errors
    )


def test_loop_ask_user_continues_in_one_run(tmp_path: Path):
    replies = iter(["main"])

    def ask_user() -> str:
        return next(replies)

    llm = _llm_responses(
        [
            AgentStep(
                action=AgentAction.NEED_USER_INPUT,
                message="Which branch?",
            ),
            AgentStep(
                action=AgentAction.TASK_COMPLETE,
                message="merged",
            ),
        ]
    )
    loop = AgentLoop(
        workspace=tmp_path, allowed_models=_ALLOWED, llm_call=llm
    )
    result = loop.run("merge", ask_user=ask_user)
    assert result.outcome == LoopOutcome.TASK_COMPLETE
    assert "main" in result.context.to_prompt()


def test_loop_repeat_question_after_reply_nudges_model(tmp_path: Path):
    """Repeated confirmation questions get a harness nudge instead of blocking."""
    replies = iter(["yes, commit"])

    def ask_user() -> str:
        return next(replies)

    same_q = "Please confirm if you'd like me to create a commit message"
    llm = _llm_responses(
        [
            AgentStep(action=AgentAction.NEED_USER_INPUT, message=same_q),
            AgentStep(action=AgentAction.NEED_USER_INPUT, message=same_q),
            AgentStep(action=AgentAction.TASK_COMPLETE, message="done"),
        ]
    )
    loop = AgentLoop(
        workspace=tmp_path,
        max_turns=10,
        allowed_models=_ALLOWED,
        llm_call=llm,
    )
    result = loop.run("commit changes", ask_user=ask_user)
    assert result.outcome == LoopOutcome.TASK_COMPLETE
    assert any("already asked" in e.lower() for e in result.context.parse_errors)


def test_loop_max_clarifications_fails(tmp_path: Path):
    replies = iter(["a", "b", "c", "d"])

    def ask_user() -> str:
        return next(replies)

    def always_ask(**_kwargs):
        return json.dumps(
            AgentStep(
                action=AgentAction.NEED_USER_INPUT,
                message="Still unclear?",
            ).model_dump(mode="json")
        )

    loop = AgentLoop(
        workspace=tmp_path,
        max_turns=20,
        max_clarifications=3,
        allowed_models=_ALLOWED,
        llm_call=always_ask,
    )
    result = loop.run("task", ask_user=ask_user)
    assert result.outcome == LoopOutcome.FAILED
    assert "too many times" in result.message


def test_loop_resumes_after_user_reply(tmp_path: Path):
    llm = _llm_responses(
        [
            AgentStep(
                action=AgentAction.NEED_USER_INPUT,
                message="Which branch?",
            ),
            AgentStep(
                action=AgentAction.TASK_COMPLETE,
                message="merged",
            ),
        ]
    )
    loop = AgentLoop(
        workspace=tmp_path, allowed_models=_ALLOWED, llm_call=llm
    )

    first = loop.run("merge")
    assert first.outcome == LoopOutcome.NEED_USER_INPUT
    first.context.add_user_reply("main")

    second = loop.run("merge", context=first.context)
    assert second.outcome == LoopOutcome.TASK_COMPLETE
    assert "main" in second.context.to_prompt()


def test_loop_stops_after_repeated_failed_shell(tmp_path: Path):
    cmd = "false"
    llm = _llm_responses(
        [
            AgentStep(action=AgentAction.RUN_SHELL, command=cmd),
            AgentStep(action=AgentAction.RUN_SHELL, command=cmd),
            AgentStep(action=AgentAction.RUN_SHELL, command=cmd),
        ]
    )
    loop = AgentLoop(
        workspace=tmp_path,
        max_turns=10,
        allowed_models=_ALLOWED,
        llm_call=llm,
    )
    result = loop.run("run failing command")
    assert result.outcome == LoopOutcome.FAILED
    assert "repeatedly" in result.message.lower()
    assert len(result.context.turns) == 2


def test_loop_switch_tools_enables_hosted_tools(tmp_path: Path):
    calls: list[dict] = []

    def tracking_llm(**kwargs):
        calls.append(dict(kwargs))
        if len(calls) == 1:
            return json.dumps(
                AgentStep(
                    action=AgentAction.SWITCH_TOOLS,
                    tools=["web_search"],
                ).model_dump(mode="json")
            )
        return json.dumps(
            AgentStep(
                action=AgentAction.TASK_COMPLETE,
                message="Sunny, 18°C in London.",
            ).model_dump(mode="json")
        )

    loop = AgentLoop(
        workspace=tmp_path,
        max_turns=5,
        allowed_models=_ALLOWED,
        model="gpt-5.4-nano",
        llm_call=tracking_llm,
    )
    result = loop.run("what is the weather in London")
    assert result.outcome == LoopOutcome.TASK_COMPLETE
    assert result.message == "Sunny, 18°C in London."
    assert len(calls) == 2
    assert "tools" not in calls[0]
    assert calls[1]["tools"] == ["web_search"]
    assert result.context.active_hosted_tools == ["web_search"]


def test_loop_switch_tools_rejects_web_search_on_gpt41_nano(tmp_path: Path):
    llm_calls: list[dict] = []

    def llm(**kwargs):
        llm_calls.append(dict(kwargs))
        if len(llm_calls) == 1:
            return json.dumps(
                {
                    "action": "switch_tools",
                    "tools": ["web_search"],
                }
            )
        return json.dumps(
            AgentStep(
                action=AgentAction.TASK_COMPLETE,
                message="done",
            ).model_dump(mode="json")
        )

    loop = AgentLoop(
        workspace=tmp_path,
        max_turns=5,
        allowed_models=_ALLOWED,
        model="gpt-4.1-nano",
        llm_call=llm,
    )
    result = loop.run("weather in London")
    assert result.outcome == LoopOutcome.TASK_COMPLETE
    assert any(
        "does not support hosted tool 'web_search'" in e
        and "gpt-4.1-nano" in e
        for e in result.context.parse_errors
    )
    assert len(llm_calls) == 2
    assert "tools" not in llm_calls[0]
    assert "tools" not in llm_calls[1]
    assert result.context.active_hosted_tools == []


def test_loop_stop_requested_before_tool_still_runs_planned_command(tmp_path: Path):
    calls = {"n": 0}

    def llm(**_kwargs):
        calls["n"] += 1
        return json.dumps(
            AgentStep(
                action=AgentAction.RUN_SHELL,
                command="echo paused-step",
                thought="Echoed a line for the user.",
            ).model_dump(mode="json")
        )

    loop = AgentLoop(
        workspace=tmp_path,
        max_turns=5,
        allowed_models=_ALLOWED,
        llm_call=llm,
    )
    result = loop.run("echo then pause", stop_requested=lambda: True)

    assert result.outcome == LoopOutcome.STOPPED
    assert calls["n"] == 1
    assert len(result.context.turns) == 1
    assert result.context.turns[0].tool_result is not None
    assert "paused-step" in result.context.turns[0].tool_result.stdout
    assert "Echoed a line for the user." in result.message
    assert "Paused — say continue when you're ready." in result.message


def test_loop_stop_requested_during_tool_pauses_after_tool_step(tmp_path: Path):
    calls = {"n": 0}
    stop_checks = iter([True])

    def llm(**_kwargs):
        calls["n"] += 1
        if calls["n"] == 1:
            return json.dumps(
                AgentStep(
                    action=AgentAction.RUN_SHELL,
                    command="echo current-step",
                ).model_dump(mode="json")
            )
        return json.dumps(
            AgentStep(
                action=AgentAction.TASK_COMPLETE,
                message="should not run yet",
            ).model_dump(mode="json")
        )

    loop = AgentLoop(
        workspace=tmp_path,
        max_turns=5,
        allowed_models=_ALLOWED,
        llm_call=llm,
    )
    result = loop.run("echo then pause", stop_requested=lambda: next(stop_checks))

    assert result.outcome == LoopOutcome.STOPPED
    assert calls["n"] == 1
    assert len(result.context.turns) == 1
    assert result.context.turns[0].tool_result is not None
    assert "current-step" in result.context.turns[0].tool_result.stdout
    assert "Paused — say continue when you're ready." in result.message


def test_loop_user_abort_during_llm_returns_stopped_immediately(tmp_path: Path):
    """A UserAbort raised mid-stream must short-circuit to STOPPED, not propagate."""
    from llm import UserAbort

    def llm(**_kwargs):
        raise UserAbort()

    loop = AgentLoop(
        workspace=tmp_path,
        max_turns=5,
        allowed_models=_ALLOWED,
        llm_call=llm,
    )
    result = loop.run("interrupt me")

    assert result.outcome == LoopOutcome.STOPPED
    assert "Paused" in result.message
    assert result.context.turns == []


def test_loop_abort_after_tool_returns_stopped(tmp_path: Path):
    """When the UI reports abort after a tool runs, the loop returns STOPPED."""
    ui = ConversationUI()

    def llm(**_kwargs):
        ui.request_abort()
        return json.dumps(
            AgentStep(
                action=AgentAction.RUN_SHELL,
                command="echo hi",
            ).model_dump(mode="json")
        )

    loop = AgentLoop(
        workspace=tmp_path,
        max_turns=5,
        allowed_models=_ALLOWED,
        llm_call=llm,
        ui=ui,
    )
    result = loop.run("run something then abort")
    assert result.outcome == LoopOutcome.STOPPED
    assert len(result.context.turns) == 1
    assert result.context.turns[0].tool_result is not None


def test_loop_resume_after_stop_continues_from_existing_context(tmp_path: Path):
    calls = {"n": 0}
    stop_checks = iter([True, False])

    def llm(**_kwargs):
        calls["n"] += 1
        if calls["n"] == 1:
            return json.dumps(
                AgentStep(
                    action=AgentAction.RUN_SHELL,
                    command="echo first",
                ).model_dump(mode="json")
            )
        return json.dumps(
            AgentStep(
                action=AgentAction.TASK_COMPLETE,
                message="resumed",
            ).model_dump(mode="json")
        )

    loop = AgentLoop(
        workspace=tmp_path,
        max_turns=5,
        allowed_models=_ALLOWED,
        llm_call=llm,
    )

    first = loop.run("pause me", stop_requested=lambda: next(stop_checks))
    assert first.outcome == LoopOutcome.STOPPED

    second = loop.run("pause me", context=first.context, stop_requested=lambda: next(stop_checks))
    assert second.outcome == LoopOutcome.TASK_COMPLETE
    assert second.message == "resumed"
    assert calls["n"] == 2
    assert len(second.context.turns) == 2


# ---------------------------------------------------------------------------
# Phase 2: previous_response_id chaining
# ---------------------------------------------------------------------------


def test_response_chain_sends_delta_and_previous_id_after_first_call(
    tmp_path: Path, monkeypatch
):
    calls: list[dict] = []
    payloads = [
        json.dumps(
            AgentStep(
                action=AgentAction.RUN_SHELL,
                command="echo chain-test",
            ).model_dump(mode="json")
        ),
        json.dumps(
            AgentStep(
                action=AgentAction.TASK_COMPLETE,
                message="done",
            ).model_dump(mode="json")
        ),
    ]

    def fake_with_id(**kwargs):
        calls.append(dict(kwargs))
        idx = len(calls) - 1
        return payloads[idx], f"resp_{idx}", None

    monkeypatch.setattr(
        "agent.loop.complete_structured_with_id", fake_with_id
    )

    loop = AgentLoop(
        workspace=tmp_path,
        max_turns=5,
        allowed_models=_ALLOWED,
        # llm_call=None enables chaining when response_chain_enabled is True.
        response_chain_enabled=True,
    )
    result = loop.run("explore")
    assert result.outcome == LoopOutcome.TASK_COMPLETE
    assert len(calls) == 2

    # First call: full prompt, no previous_response_id.
    first = calls[0]
    assert "previous_response_id" not in first
    assert "## User task" in first["input"]

    # Second call: delta input, chained.
    second = calls[1]
    assert second["previous_response_id"] == "resp_0"
    # Delta drops the user_task header and only includes the new tool result.
    assert "## User task" not in second["input"]
    assert "chain-test" in second["input"]


def test_response_chain_recovers_when_server_drops_chain(
    tmp_path: Path, monkeypatch
):
    from llm import ResponseChainBroken

    calls: list[dict] = []
    payloads = [
        (
            json.dumps(
                AgentStep(
                    action=AgentAction.RUN_SHELL,
                    command="echo first",
                ).model_dump(mode="json")
            ),
            "resp_0",
        ),
        # Second call raises chain-broken; loop should recover and retry once.
        ResponseChainBroken("Previous response with id resp_0 not found"),
        (
            json.dumps(
                AgentStep(
                    action=AgentAction.TASK_COMPLETE,
                    message="recovered",
                ).model_dump(mode="json")
            ),
            "resp_2",
        ),
    ]

    def fake_with_id(**kwargs):
        calls.append(dict(kwargs))
        outcome = payloads[len(calls) - 1]
        if isinstance(outcome, BaseException):
            raise outcome
        text, rid = outcome
        return text, rid, None

    monkeypatch.setattr(
        "agent.loop.complete_structured_with_id", fake_with_id
    )

    loop = AgentLoop(
        workspace=tmp_path,
        max_turns=5,
        allowed_models=_ALLOWED,
        response_chain_enabled=True,
    )
    result = loop.run("explore")
    assert result.outcome == LoopOutcome.TASK_COMPLETE
    assert result.message == "recovered"

    # Three underlying calls: first ok, second chain-broken, third recovery.
    assert len(calls) == 3
    # The recovery call drops previous_response_id and re-sends a full prompt.
    recovery = calls[2]
    assert "previous_response_id" not in recovery
    assert "## User task" in recovery["input"]


def test_response_chain_disabled_uses_full_prompt_each_turn(
    tmp_path: Path, monkeypatch
):
    """With chaining off, every call gets the full prompt and no previous id."""
    calls: list[dict] = []
    payloads = [
        json.dumps(
            AgentStep(
                action=AgentAction.RUN_SHELL,
                command="echo a",
            ).model_dump(mode="json")
        ),
        json.dumps(
            AgentStep(
                action=AgentAction.TASK_COMPLETE,
                message="ok",
            ).model_dump(mode="json")
        ),
    ]

    def fake_with_id(**kwargs):
        calls.append(dict(kwargs))
        return payloads[len(calls) - 1], f"resp_{len(calls) - 1}", None

    monkeypatch.setattr(
        "agent.loop.complete_structured_with_id", fake_with_id
    )

    loop = AgentLoop(
        workspace=tmp_path,
        max_turns=5,
        allowed_models=_ALLOWED,
        response_chain_enabled=False,
    )
    result = loop.run("explore")
    assert result.outcome == LoopOutcome.TASK_COMPLETE
    assert len(calls) == 2
    for call in calls:
        assert "previous_response_id" not in call
        assert "## User task" in call["input"]


def test_llm_stream_updates_thinking_label(tmp_path: Path, monkeypatch):
    from agent.ui import ThinkingUpdater

    status_updates: list[str] = []
    original_update = ThinkingUpdater.update

    def track_update(self, label: str) -> None:
        status_updates.append(label)
        original_update(self, label)

    monkeypatch.setattr(ThinkingUpdater, "update", track_update)

    payload = json.dumps(
        AgentStep(
            action=AgentAction.TASK_COMPLETE,
            message="done",
        ).model_dump(mode="json")
    )

    def fake_with_id(**kwargs):
        on_delta = kwargs.get("on_text_delta")
        assert kwargs.get("stream") is True
        if on_delta:
            on_delta('{"status": "Inspecting project structure", ')
            on_delta('"action": "task_complete", "message": "done"}')
        return payload, "resp_0", None

    monkeypatch.setattr(
        "agent.loop.complete_structured_with_id", fake_with_id
    )

    loop = AgentLoop(
        workspace=tmp_path,
        max_turns=3,
        allowed_models=_ALLOWED,
        ui=ConversationUI(),
    )
    result = loop.run("explore")
    assert result.outcome == LoopOutcome.TASK_COMPLETE
    assert "Inspecting project structure" in status_updates


def test_complex_task_blocks_edit_until_plan(tmp_path: Path):
    target = tmp_path / "x.txt"
    target.write_text("old\n", encoding="utf-8")
    loop = AgentLoop(
        workspace=tmp_path,
        max_turns=8,
        allowed_models=_ALLOWED,
        llm_call=_llm_responses(
            [
                AgentStep(
                    action=AgentAction.STR_REPLACE,
                    path="x.txt",
                    old_string="old",
                    new_string="new",
                ),
                AgentStep(
                    action=AgentAction.UPDATE_PLAN,
                    plan_items=[
                        PlanItem(id="1", text="recon", status=PlanItemStatus.DONE),
                        PlanItem(
                            id="2",
                            text="edit file",
                            status=PlanItemStatus.IN_PROGRESS,
                        ),
                    ],
                ),
                AgentStep(
                    action=AgentAction.STR_REPLACE,
                    path="x.txt",
                    old_string="old",
                    new_string="new",
                ),
                AgentStep(
                    action=AgentAction.RUN_SHELL,
                    command="python3 -m pytest --version",
                ),
                AgentStep(
                    action=AgentAction.TASK_COMPLETE,
                    message="done",
                ),
            ]
        ),
    )
    result = loop.run("refactor x.txt naming")
    assert result.outcome == LoopOutcome.TASK_COMPLETE
    assert target.read_text(encoding="utf-8") == "new\n"
    assert "update_plan" in result.context.parse_errors[0].lower()


def test_verify_gate_blocks_task_complete_until_pytest(tmp_path: Path):
    target = tmp_path / "y.txt"
    target.write_text("a\n", encoding="utf-8")
    loop = AgentLoop(
        workspace=tmp_path,
        max_turns=10,
        allowed_models=_ALLOWED,
        llm_call=_llm_responses(
            [
                AgentStep(
                    action=AgentAction.STR_REPLACE,
                    path="y.txt",
                    old_string="a",
                    new_string="b",
                ),
                AgentStep(
                    action=AgentAction.TASK_COMPLETE,
                    message="done without test",
                ),
                AgentStep(
                    action=AgentAction.RUN_SHELL,
                    command="true",
                ),
                AgentStep(
                    action=AgentAction.TASK_COMPLETE,
                    message="still no pytest",
                ),
                AgentStep(
                    action=AgentAction.RUN_SHELL,
                    command="python3 -m pytest --version",
                ),
                AgentStep(
                    action=AgentAction.TASK_COMPLETE,
                    message="verified",
                ),
            ]
        ),
    )
    result = loop.run("fix y.txt")
    assert result.outcome == LoopOutcome.TASK_COMPLETE
    assert result.message == "verified"
    assert any(
        "verification" in e.lower() or "test" in e.lower()
        for e in result.context.parse_errors
    )


def test_verify_gate_disabled_via_env(tmp_path: Path, monkeypatch):
    env_file = tmp_path / ".env"
    env_file.write_text("GOODBOY_VERIFY_BEFORE_COMPLETE=false\n", encoding="utf-8")
    monkeypatch.setattr("settings.ENV_FILE", env_file)
    from settings import get_settings

    get_settings.cache_clear()

    target = tmp_path / "z.txt"
    target.write_text("1\n", encoding="utf-8")
    loop = AgentLoop(
        workspace=tmp_path,
        max_turns=5,
        allowed_models=_ALLOWED,
        llm_call=_llm_responses(
            [
                AgentStep(
                    action=AgentAction.STR_REPLACE,
                    path="z.txt",
                    old_string="1",
                    new_string="2",
                ),
                AgentStep(
                    action=AgentAction.TASK_COMPLETE,
                    message="ok",
                ),
            ]
        ),
    )
    result = loop.run("update z")
    assert result.outcome == LoopOutcome.TASK_COMPLETE
    get_settings.cache_clear()


def test_remember_appends_working_memory(tmp_path: Path):
    loop = AgentLoop(
        workspace=tmp_path,
        max_turns=5,
        allowed_models=_ALLOWED,
        llm_call=_llm_responses(
            [
                AgentStep(
                    action=AgentAction.REMEMBER,
                    memory=["Tests: pytest tests/ -q"],
                ),
                AgentStep(
                    action=AgentAction.TASK_COMPLETE,
                    message="ok",
                ),
            ]
        ),
    )
    result = loop.run("note tests")
    assert result.outcome == LoopOutcome.TASK_COMPLETE
    assert "pytest" in result.context.working_memory[0]
    assert "Working memory" in result.context.to_prompt()


# ---------------------------------------------------------------------------
# Phase 3: parallel batch dispatch for read-only harness tools
# ---------------------------------------------------------------------------


def _bundle_steps(*steps: AgentStep) -> str:
    """Concatenate AgentStep JSON payloads (the on-the-wire batch shape)."""
    return "".join(
        json.dumps(s.model_dump(mode="json"), separators=(",", ":")) for s in steps
    )


def test_loop_batched_read_only_actions_run_in_one_turn(tmp_path: Path):
    """Three read_files in one response → three turn records, one LLM call."""
    (tmp_path / "a.txt").write_text("alpha\n", encoding="utf-8")
    (tmp_path / "b.txt").write_text("bravo\n", encoding="utf-8")
    (tmp_path / "c.txt").write_text("charlie\n", encoding="utf-8")

    payloads = [
        _bundle_steps(
            AgentStep(action=AgentAction.READ_FILE, path="a.txt"),
            AgentStep(action=AgentAction.READ_FILE, path="b.txt"),
            AgentStep(action=AgentAction.READ_FILE, path="c.txt"),
        ),
        json.dumps(
            AgentStep(
                action=AgentAction.TASK_COMPLETE, message="done"
            ).model_dump(mode="json")
        ),
    ]
    calls = {"n": 0}

    def llm(**_kwargs):
        idx = calls["n"]
        calls["n"] += 1
        return payloads[idx]

    loop = AgentLoop(
        workspace=tmp_path,
        max_turns=5,
        allowed_models=_ALLOWED,
        llm_call=llm,
    )
    result = loop.run("read three files in parallel")

    assert result.outcome == LoopOutcome.TASK_COMPLETE
    # One batched LLM call + one task_complete call.
    assert calls["n"] == 2
    # Three batched read records + the terminal task_complete record.
    assert len(result.context.turns) == 4
    batched = result.context.turns[:3]
    # Each batched record is tagged with the same LLM-call turn number.
    assert {t.turn for t in batched} == {1}
    assert [t.step.path for t in batched] == ["a.txt", "b.txt", "c.txt"]
    assert "alpha" in batched[0].tool_result.stdout
    assert "bravo" in batched[1].tool_result.stdout
    assert "charlie" in batched[2].tool_result.stdout


def test_loop_batched_reads_dispatch_concurrently(tmp_path: Path, monkeypatch):
    """Wall-clock for N batched reads should be ~one tool's runtime, not N×."""
    import time

    sleep_for = 0.25
    starts: list[float] = []

    def slow_run_harness_tool(self, step: AgentStep) -> ToolResult:
        starts.append(time.monotonic())
        time.sleep(sleep_for)
        return ToolResult(
            executed=f"fake {step.path}",
            stdout=f"ok {step.path}",
            exit_code=0,
        )

    monkeypatch.setattr(AgentLoop, "_run_harness_tool", slow_run_harness_tool)

    payloads = [
        _bundle_steps(
            AgentStep(action=AgentAction.READ_FILE, path="a.txt"),
            AgentStep(action=AgentAction.READ_FILE, path="b.txt"),
            AgentStep(action=AgentAction.READ_FILE, path="c.txt"),
            AgentStep(action=AgentAction.READ_FILE, path="d.txt"),
        ),
        json.dumps(
            AgentStep(
                action=AgentAction.TASK_COMPLETE, message="done"
            ).model_dump(mode="json")
        ),
    ]
    calls = {"n": 0}

    def llm(**_kwargs):
        idx = calls["n"]
        calls["n"] += 1
        return payloads[idx]

    loop = AgentLoop(
        workspace=tmp_path,
        max_turns=5,
        allowed_models=_ALLOWED,
        llm_call=llm,
    )

    t0 = time.monotonic()
    result = loop.run("four parallel reads")
    elapsed = time.monotonic() - t0

    assert result.outcome == LoopOutcome.TASK_COMPLETE
    assert len(starts) == 4
    # All four workers should be in flight together; allow generous slack for
    # CI scheduling jitter (well under the serial bound 4 * sleep_for = 1.0s).
    assert elapsed < 2.5 * sleep_for, (
        f"Expected concurrent dispatch but loop took {elapsed:.3f}s"
    )


def test_loop_batched_reads_with_update_plan_piggyback(tmp_path: Path):
    """Bundling an update_plan alongside batched reads applies the plan once."""
    (tmp_path / "a.txt").write_text("alpha\n", encoding="utf-8")
    (tmp_path / "b.txt").write_text("bravo\n", encoding="utf-8")

    payloads = [
        _bundle_steps(
            AgentStep(action=AgentAction.READ_FILE, path="a.txt"),
            AgentStep(action=AgentAction.READ_FILE, path="b.txt"),
            AgentStep(
                action=AgentAction.UPDATE_PLAN,
                plan_items=[
                    PlanItem(
                        id="1", text="recon", status=PlanItemStatus.IN_PROGRESS
                    ),
                    PlanItem(
                        id="2", text="implement", status=PlanItemStatus.PENDING
                    ),
                ],
            ),
        ),
        json.dumps(
            AgentStep(
                action=AgentAction.TASK_COMPLETE, message="done"
            ).model_dump(mode="json")
        ),
    ]
    calls = {"n": 0}

    def llm(**_kwargs):
        idx = calls["n"]
        calls["n"] += 1
        return payloads[idx]

    loop = AgentLoop(
        workspace=tmp_path,
        max_turns=5,
        allowed_models=_ALLOWED,
        llm_call=llm,
    )
    result = loop.run("parallel reads with plan")

    assert result.outcome == LoopOutcome.TASK_COMPLETE
    # Two batched read records + task_complete (the bundled update_plan is a
    # piggy-backed side-effect, not its own dispatched turn).
    assert len(result.context.turns) == 3
    assert [t.step.action for t in result.context.turns[:2]] == [
        AgentAction.READ_FILE,
        AgentAction.READ_FILE,
    ]
    assert [p.text for p in result.context.plan_items] == ["recon", "implement"]


def test_loop_batch_falls_back_when_response_mixes_writes(tmp_path: Path):
    """A read bundled with run_shell disables batching: only the first runs."""
    (tmp_path / "a.txt").write_text("alpha\n", encoding="utf-8")

    payloads = [
        _bundle_steps(
            AgentStep(action=AgentAction.READ_FILE, path="a.txt"),
            AgentStep(action=AgentAction.RUN_SHELL, command="echo unwanted"),
        ),
        json.dumps(
            AgentStep(
                action=AgentAction.TASK_COMPLETE, message="done"
            ).model_dump(mode="json")
        ),
    ]
    calls = {"n": 0}

    def llm(**_kwargs):
        idx = calls["n"]
        calls["n"] += 1
        return payloads[idx]

    loop = AgentLoop(
        workspace=tmp_path,
        max_turns=5,
        allowed_models=_ALLOWED,
        llm_call=llm,
    )
    result = loop.run("mixed bundle")

    assert result.outcome == LoopOutcome.TASK_COMPLETE
    # Only the first action ran (single-step fallback); echo never executed.
    assert len(result.context.turns) == 2
    assert result.context.turns[0].step.action == AgentAction.READ_FILE
    assert all(
        t.step.action != AgentAction.RUN_SHELL for t in result.context.turns
    )


def test_loop_single_read_action_skips_batch_path(tmp_path: Path):
    """A response with one read action keeps the existing single-step flow."""
    (tmp_path / "a.txt").write_text("alpha\n", encoding="utf-8")

    payloads = [
        json.dumps(
            AgentStep(
                action=AgentAction.READ_FILE, path="a.txt"
            ).model_dump(mode="json")
        ),
        json.dumps(
            AgentStep(
                action=AgentAction.TASK_COMPLETE, message="done"
            ).model_dump(mode="json")
        ),
    ]
    calls = {"n": 0}

    def llm(**_kwargs):
        idx = calls["n"]
        calls["n"] += 1
        return payloads[idx]

    loop = AgentLoop(
        workspace=tmp_path,
        max_turns=5,
        allowed_models=_ALLOWED,
        llm_call=llm,
    )
    result = loop.run("single read")

    assert result.outcome == LoopOutcome.TASK_COMPLETE
    assert len(result.context.turns) == 2
    assert result.context.turns[0].step.action == AgentAction.READ_FILE
    assert "alpha" in result.context.turns[0].tool_result.stdout
